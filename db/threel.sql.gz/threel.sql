-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le :  Dim 22 déc. 2019 à 12:03
-- Version du serveur :  5.7.23
-- Version de PHP :  7.1.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `notion`
--

-- --------------------------------------------------------

--
-- Structure de la table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `config`
--

CREATE TABLE `config` (
  `config_id` int(11) NOT NULL,
  `config_key` varchar(255) NOT NULL,
  `config_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `config`
--

INSERT INTO `config` (`config_id`, `config_key`, `config_value`) VALUES
(1, 'db_version', '1'),
(11, 'site_closed', '0');

-- --------------------------------------------------------

--
-- Structure de la table `grp`
--

CREATE TABLE `grp` (
  `grp_id` int(11) NOT NULL,
  `grp_name` varchar(255) NOT NULL,
  `grp_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `grp`
--

INSERT INTO `grp` (`grp_id`, `grp_name`, `grp_description`) VALUES
(1, 'all', 'all users'),
(21, 'admins', 'admin users');

-- --------------------------------------------------------

--
-- Structure de la table `language`
--

CREATE TABLE `language` (
  `language_id` varchar(10) NOT NULL,
  `language_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `language`
--

INSERT INTO `language` (`language_id`, `language_name`) VALUES
('english', 'English'),
('french', 'Français');

-- --------------------------------------------------------

--
-- Structure de la table `org`
--

CREATE TABLE `org` (
  `org_id` int(11) NOT NULL,
  `org_name` varchar(255) NOT NULL,
  `org_client_id` varchar(80) NOT NULL,
  `org_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile_no` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT '1',
  `is_active` tinyint(4) NOT NULL DEFAULT '1',
  `is_verify` tinyint(4) NOT NULL DEFAULT '0',
  `is_admin` tinyint(4) NOT NULL DEFAULT '0',
  `token` varchar(255) NOT NULL,
  `password_reset_code` varchar(255) NOT NULL,
  `last_ip` varchar(30) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `org_id` int(11) NOT NULL,
  `source` varchar(255) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `expiration_date` datetime DEFAULT NULL,
  `import_id` int(11) NOT NULL,
  `language_id` varchar(50) NOT NULL DEFAULT 'french'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`user_id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`, `org_id`, `source`, `last_login`, `expiration_date`, `import_id`, `language_id`) VALUES
(36, 'admin', 'Admin', 'Admin', 'admin@admin.com', '', '$2y$10$rZOEUAfmG/TmvhXnWse/V.gu1gUHMTp8gygimdNwcyj6uEk8N.8Hm', '', 2, 1, 1, 1, '', '', '', '2018-12-30 12:12:04', '2019-06-04 05:06:25', 0, 'manual', '2019-12-21 17:50:08', NULL, 0, 'french');

-- --------------------------------------------------------

--
-- Structure de la table `user_grp`
--

CREATE TABLE `user_grp` (
  `user_grp_id` int(11) NOT NULL,
  `user_grp_user_id` int(11) NOT NULL,
  `user_grp_grp_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `user_grp`
--

INSERT INTO `user_grp` (`user_grp_id`, `user_grp_user_id`, `user_grp_grp_id`) VALUES
(1, 36, 1),
(21, 36, 21);

-- --------------------------------------------------------

--
-- Structure de la table `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `group_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `user_role`
--

INSERT INTO `user_role` (`id`, `group_name`) VALUES
(1, 'User'),
(2, 'Admin');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Index pour la table `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`config_id`),
  ADD UNIQUE KEY `config_key` (`config_key`);

--
-- Index pour la table `grp`
--
ALTER TABLE `grp`
  ADD PRIMARY KEY (`grp_id`);

--
-- Index pour la table `language`
--
ALTER TABLE `language`
  ADD UNIQUE KEY `language_id` (`language_id`);

--
-- Index pour la table `org`
--
ALTER TABLE `org`
  ADD PRIMARY KEY (`org_id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Index pour la table `user_grp`
--
ALTER TABLE `user_grp`
  ADD PRIMARY KEY (`user_grp_id`),
  ADD KEY `fk_user_grp_user_id` (`user_grp_user_id`),
  ADD KEY `fk_user_grp_grp_id` (`user_grp_grp_id`);

--
-- Index pour la table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `config`
--
ALTER TABLE `config`
  MODIFY `config_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `grp`
--
ALTER TABLE `grp`
  MODIFY `grp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT pour la table `org`
--
ALTER TABLE `org`
  MODIFY `org_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT pour la table `user_grp`
--
ALTER TABLE `user_grp`
  MODIFY `user_grp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT pour la table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `user_grp`
--
ALTER TABLE `user_grp`
  ADD CONSTRAINT `fk_user_grp_grp_id` FOREIGN KEY (`user_grp_grp_id`) REFERENCES `grp` (`grp_id`),
  ADD CONSTRAINT `fk_user_grp_user_id` FOREIGN KEY (`user_grp_user_id`) REFERENCES `user` (`user_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
